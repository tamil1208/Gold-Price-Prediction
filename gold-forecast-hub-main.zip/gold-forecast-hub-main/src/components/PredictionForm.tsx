import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Calendar, DollarSign, TrendingUp, Loader2, AlertCircle, Percent, BarChart2, Landmark } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import type { PredictionInput, PredictionResult } from '@/types/gold';

// Mock prediction function (ready to connect to backend)
const mockPredict = async (input: PredictionInput): Promise<PredictionResult> => {
  // Simulate API call
  await new Promise(resolve => setTimeout(resolve, 2000));
  
  // Generate mock prediction based on inputs
  const basePrice = 2150;
  const variation = Math.random() * 100 - 50;
  const predictedPrice = basePrice + variation;
  
  // Convert to INR if needed (mock rate)
  const finalPrice = input.currency === 'INR' ? predictedPrice * 83.5 : predictedPrice;
  
  return {
    predictedPrice: Math.round(finalPrice * 100) / 100,
    currency: input.currency,
    confidence: Math.round((85 + Math.random() * 10) * 10) / 10,
    date: input.date,
    trend: variation > 10 ? 'up' : variation < -10 ? 'down' : 'stable',
  };
};

const PredictionForm = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<PredictionResult | null>(null);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [formData, setFormData] = useState<PredictionInput>({
    date: new Date().toISOString().split('T')[0],
    currency: 'USD',
    inflationRate: undefined,
    usdIndex: undefined,
    interestRate: undefined,
  });
  const [errors, setErrors] = useState<Partial<Record<keyof PredictionInput, string>>>({});

  const validateForm = (): boolean => {
    const newErrors: typeof errors = {};
    
    if (!formData.date) {
      newErrors.date = 'Date is required';
    }
    
    if (formData.inflationRate !== undefined && (formData.inflationRate < 0 || formData.inflationRate > 100)) {
      newErrors.inflationRate = 'Inflation rate must be between 0 and 100';
    }
    
    if (formData.usdIndex !== undefined && (formData.usdIndex < 0 || formData.usdIndex > 200)) {
      newErrors.usdIndex = 'USD Index must be between 0 and 200';
    }
    
    if (formData.interestRate !== undefined && (formData.interestRate < 0 || formData.interestRate > 50)) {
      newErrors.interestRate = 'Interest rate must be between 0 and 50';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      toast.error('Please fix the form errors');
      return;
    }
    
    setIsLoading(true);
    setResult(null);
    
    try {
      const prediction = await mockPredict(formData);
      setResult(prediction);
      toast.success('Prediction generated successfully!');
    } catch (error) {
      toast.error('Failed to generate prediction. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const formatPrice = (price: number, currency: 'INR' | 'USD') => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 2,
    }).format(price);
  };

  return (
    <section id="prediction" className="py-20 gradient-bg">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold font-display mb-4">
            Get Your <span className="gold-text">Prediction</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Enter the parameters below to receive an AI-powered gold price prediction
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {/* Form */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <form onSubmit={handleSubmit} className="glass-card p-6 md:p-8 space-y-6">
              <div className="space-y-4">
                {/* Date Input */}
                <div className="space-y-2">
                  <Label htmlFor="date" className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-primary" />
                    Prediction Date
                  </Label>
                  <Input
                    id="date"
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    className="bg-input border-border focus:ring-primary"
                  />
                  {errors.date && (
                    <p className="text-sm text-destructive flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" /> {errors.date}
                    </p>
                  )}
                </div>

                {/* Currency Select */}
                <div className="space-y-2">
                  <Label className="flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-primary" />
                    Currency
                  </Label>
                  <Select
                    value={formData.currency}
                    onValueChange={(value: 'INR' | 'USD') => setFormData({ ...formData, currency: value })}
                  >
                    <SelectTrigger className="bg-input border-border">
                      <SelectValue placeholder="Select currency" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="USD">USD ($)</SelectItem>
                      <SelectItem value="INR">INR (₹)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Advanced Options Toggle */}
                <Button
                  type="button"
                  variant="ghost"
                  onClick={() => setShowAdvanced(!showAdvanced)}
                  className="w-full justify-start text-muted-foreground hover:text-foreground"
                >
                  <BarChart2 className="w-4 h-4 mr-2" />
                  {showAdvanced ? 'Hide' : 'Show'} Advanced Options
                </Button>

                {/* Advanced Options */}
                <AnimatePresence>
                  {showAdvanced && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      transition={{ duration: 0.3 }}
                      className="space-y-4 overflow-hidden"
                    >
                      {/* Inflation Rate */}
                      <div className="space-y-2">
                        <Label htmlFor="inflationRate" className="flex items-center gap-2">
                          <Percent className="w-4 h-4 text-primary" />
                          Inflation Rate (%)
                        </Label>
                        <Input
                          id="inflationRate"
                          type="number"
                          step="0.1"
                          placeholder="e.g., 3.5"
                          value={formData.inflationRate ?? ''}
                          onChange={(e) => setFormData({ 
                            ...formData, 
                            inflationRate: e.target.value ? parseFloat(e.target.value) : undefined 
                          })}
                          className="bg-input border-border"
                        />
                        {errors.inflationRate && (
                          <p className="text-sm text-destructive flex items-center gap-1">
                            <AlertCircle className="w-3 h-3" /> {errors.inflationRate}
                          </p>
                        )}
                      </div>

                      {/* USD Index */}
                      <div className="space-y-2">
                        <Label htmlFor="usdIndex" className="flex items-center gap-2">
                          <TrendingUp className="w-4 h-4 text-primary" />
                          USD Index
                        </Label>
                        <Input
                          id="usdIndex"
                          type="number"
                          step="0.01"
                          placeholder="e.g., 104.5"
                          value={formData.usdIndex ?? ''}
                          onChange={(e) => setFormData({ 
                            ...formData, 
                            usdIndex: e.target.value ? parseFloat(e.target.value) : undefined 
                          })}
                          className="bg-input border-border"
                        />
                        {errors.usdIndex && (
                          <p className="text-sm text-destructive flex items-center gap-1">
                            <AlertCircle className="w-3 h-3" /> {errors.usdIndex}
                          </p>
                        )}
                      </div>

                      {/* Interest Rate */}
                      <div className="space-y-2">
                        <Label htmlFor="interestRate" className="flex items-center gap-2">
                          <Landmark className="w-4 h-4 text-primary" />
                          Interest Rate (%)
                        </Label>
                        <Input
                          id="interestRate"
                          type="number"
                          step="0.1"
                          placeholder="e.g., 5.25"
                          value={formData.interestRate ?? ''}
                          onChange={(e) => setFormData({ 
                            ...formData, 
                            interestRate: e.target.value ? parseFloat(e.target.value) : undefined 
                          })}
                          className="bg-input border-border"
                        />
                        {errors.interestRate && (
                          <p className="text-sm text-destructive flex items-center gap-1">
                            <AlertCircle className="w-3 h-3" /> {errors.interestRate}
                          </p>
                        )}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Submit Button */}
              <Button
                type="submit"
                disabled={isLoading}
                className="w-full bg-primary text-primary-foreground font-semibold py-6 gold-glow hover:brightness-110 transition-all"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    Analyzing Market Data...
                  </>
                ) : (
                  <>
                    <TrendingUp className="w-5 h-5 mr-2" />
                    Predict Gold Price
                  </>
                )}
              </Button>
            </form>
          </motion.div>

          {/* Result Card */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="flex items-center"
          >
            <AnimatePresence mode="wait">
              {isLoading ? (
                <motion.div
                  key="loading"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="glass-card p-8 w-full text-center"
                >
                  <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-primary/20 flex items-center justify-center pulse-gold">
                    <Loader2 className="w-10 h-10 text-primary animate-spin" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Processing Your Request</h3>
                  <p className="text-muted-foreground">Analyzing historical data and market indicators...</p>
                  <div className="mt-6 space-y-2">
                    {['Loading historical data...', 'Running ML model...', 'Generating prediction...'].map((text, i) => (
                      <div key={text} className="h-2 rounded-full shimmer" style={{ animationDelay: `${i * 0.2}s` }} />
                    ))}
                  </div>
                </motion.div>
              ) : result ? (
                <motion.div
                  key="result"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="glass-card p-8 w-full"
                >
                  <div className="text-center mb-6">
                    <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-success/20 text-success mb-4">
                      <div className="w-2 h-2 rounded-full bg-success animate-pulse" />
                      Prediction Complete
                    </div>
                    <h3 className="text-xl font-semibold">Predicted Gold Price</h3>
                    <p className="text-muted-foreground">for {new Date(result.date).toLocaleDateString('en-US', { 
                      weekday: 'long', 
                      year: 'numeric', 
                      month: 'long', 
                      day: 'numeric' 
                    })}</p>
                  </div>

                  <div className="text-center mb-8">
                    <div className="text-5xl md:text-6xl font-bold gold-text font-display">
                      {formatPrice(result.predictedPrice, result.currency)}
                    </div>
                    <div className="flex items-center justify-center gap-2 mt-3">
                      <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-sm font-medium ${
                        result.trend === 'up' 
                          ? 'bg-success/20 text-success' 
                          : result.trend === 'down' 
                            ? 'bg-destructive/20 text-destructive'
                            : 'bg-muted text-muted-foreground'
                      }`}>
                        {result.trend === 'up' ? '↑' : result.trend === 'down' ? '↓' : '→'}
                        {result.trend.charAt(0).toUpperCase() + result.trend.slice(1)} Trend
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="glass-card p-4 text-center">
                      <div className="text-2xl font-bold text-primary">{result.confidence}%</div>
                      <div className="text-sm text-muted-foreground">Confidence</div>
                    </div>
                    <div className="glass-card p-4 text-center">
                      <div className="text-2xl font-bold">{result.currency}</div>
                      <div className="text-sm text-muted-foreground">Currency</div>
                    </div>
                  </div>

                  <p className="text-xs text-muted-foreground text-center mt-6">
                    * This prediction is based on historical data and ML models. 
                    Actual prices may vary. Not financial advice.
                  </p>
                </motion.div>
              ) : (
                <motion.div
                  key="empty"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="glass-card p-8 w-full text-center"
                >
                  <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-muted flex items-center justify-center">
                    <TrendingUp className="w-10 h-10 text-muted-foreground" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Ready to Predict</h3>
                  <p className="text-muted-foreground">
                    Fill in the form and click "Predict Gold Price" to get your AI-powered prediction.
                  </p>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default PredictionForm;
