import { motion } from 'framer-motion';
import { Brain, Database, LineChart, Cpu, Layers, Zap } from 'lucide-react';

const features = [
  {
    icon: Database,
    title: 'Historical Data',
    description: 'Trained on 10+ years of gold price data including market indicators like S&P 500, crude oil, and currency exchange rates.',
  },
  {
    icon: Brain,
    title: 'Machine Learning',
    description: 'Uses advanced regression models and neural networks to identify complex patterns in historical price movements.',
  },
  {
    icon: LineChart,
    title: 'Time Series Analysis',
    description: 'Employs LSTM and ARIMA models specifically designed for sequential financial data prediction.',
  },
  {
    icon: Cpu,
    title: 'Feature Engineering',
    description: 'Incorporates multiple market indicators including inflation rates, USD index, and interest rates for accurate predictions.',
  },
  {
    icon: Layers,
    title: 'Ensemble Methods',
    description: 'Combines multiple models using ensemble techniques to improve prediction accuracy and reduce variance.',
  },
  {
    icon: Zap,
    title: 'Real-time Processing',
    description: 'Optimized for fast inference, delivering predictions in seconds while maintaining high accuracy.',
  },
];

const AboutSection = () => {
  return (
    <section id="about" className="py-20 gradient-bg">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold font-display mb-4">
            How It <span className="gold-text">Works</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Our gold price prediction system leverages cutting-edge machine learning techniques 
            to analyze historical data and market indicators.
          </p>
        </motion.div>

        {/* ML Pipeline Visualization */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="glass-card p-6 md:p-8 mb-16 max-w-4xl mx-auto"
        >
          <h3 className="text-xl font-semibold mb-6 text-center">ML Pipeline Overview</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {[
              { step: 1, label: 'Data Collection', desc: 'Historical prices & indicators' },
              { step: 2, label: 'Preprocessing', desc: 'Clean & normalize data' },
              { step: 3, label: 'Model Training', desc: 'Train ML algorithms' },
              { step: 4, label: 'Prediction', desc: 'Generate forecasts' },
            ].map((item, index) => (
              <motion.div
                key={item.step}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: 0.1 * index }}
                className="relative"
              >
                <div className="glass-card p-4 text-center relative z-10">
                  <div className="w-10 h-10 rounded-full bg-primary text-primary-foreground font-bold flex items-center justify-center mx-auto mb-3">
                    {item.step}
                  </div>
                  <h4 className="font-semibold mb-1">{item.label}</h4>
                  <p className="text-sm text-muted-foreground">{item.desc}</p>
                </div>
                {index < 3 && (
                  <div className="hidden md:block absolute top-1/2 -right-2 w-4 h-0.5 bg-primary/50 z-0" />
                )}
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 * index }}
              className="glass-card p-6 hover:bg-accent/50 transition-all group"
            >
              <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center mb-4 group-hover:bg-primary/30 transition-colors">
                <feature.icon className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
              <p className="text-muted-foreground text-sm">{feature.description}</p>
            </motion.div>
          ))}
        </div>

        {/* Disclaimer */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="mt-16 text-center"
        >
          <div className="glass-card p-6 max-w-2xl mx-auto">
            <h4 className="font-semibold mb-2 text-primary">Disclaimer</h4>
            <p className="text-sm text-muted-foreground">
              This tool is for educational and informational purposes only. Predictions are based on 
              historical data and machine learning models, which may not accurately forecast future prices. 
              Please consult a financial advisor before making investment decisions.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default AboutSection;
