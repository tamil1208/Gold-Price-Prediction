import { TrendingUp, Github, Linkedin } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="py-12 border-t border-border/50 gradient-bg">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-3 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <a href="#home" className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-primary" />
              </div>
              <span className="font-display font-bold text-lg">
                Gold<span className="gold-text">Predict</span>
              </span>
            </a>
            <p className="text-sm text-muted-foreground max-w-xs">
              AI-powered gold price prediction system using machine learning and historical market data.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <div className="space-y-2">
              {[
                { label: 'Home', href: '#home' },
                { label: 'Get Prediction', href: '#prediction' },
                { label: 'Price Trends', href: '#chart' },
                { label: 'About Project', href: '#about' },
              ].map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  className="block text-sm text-muted-foreground hover:text-foreground transition-colors"
                >
                  {link.label}
                </a>
              ))}
            </div>
          </div>

          {/* Connect */}
          <div>
            <h4 className="font-semibold mb-4">Connect</h4>
            <div className="flex gap-4">
              {[
                { icon: Github, href: 'https://github.com/tamil1208/Gold-Price-Prediction', label: 'GitHub' },
                { icon: Linkedin, href: 'https://www.linkedin.com/in/tamil-arasan-a2466b274/', label: 'LinkedIn' },
              ].map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  className="w-10 h-10 rounded-lg glass-card flex items-center justify-center hover:bg-accent transition-colors"
                  aria-label={social.label}
                >
                  <social.icon className="w-5 h-5 text-muted-foreground" />
                </a>
              ))}
            </div>
            <p className="text-sm text-muted-foreground mt-4">
              Built with React, Chart.js & Machine Learning
            </p>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-border/50 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} GoldPredict. All rights reserved.
          </p>
          <p className="text-xs text-muted-foreground">
            Disclaimer: This is for educational purposes only. Not financial advice.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
