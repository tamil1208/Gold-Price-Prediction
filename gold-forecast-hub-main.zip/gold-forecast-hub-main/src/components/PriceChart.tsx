import { useEffect, useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from 'chart.js';
import Papa from 'papaparse';
import { TrendingUp, TrendingDown, Calendar, Activity } from 'lucide-react';
import type { GoldPriceData } from '@/types/gold';

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

const PriceChart = () => {
  const [chartData, setChartData] = useState<GoldPriceData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [timeRange, setTimeRange] = useState<'1Y' | '5Y' | 'ALL'>('ALL');

  useEffect(() => {
    const loadData = async () => {
      try {
        const response = await fetch('/data/gold_price_data.csv');
        const csvText = await response.text();
        
        Papa.parse<GoldPriceData>(csvText, {
          header: true,
          dynamicTyping: true,
          skipEmptyLines: true,
          complete: (results) => {
            setChartData(results.data);
            setIsLoading(false);
          },
          error: () => {
            setIsLoading(false);
          },
        });
      } catch (error) {
        setIsLoading(false);
      }
    };

    loadData();
  }, []);

  const filteredData = useMemo(() => {
    if (!chartData.length) return [];
    
    const now = new Date();
    let cutoffDate: Date;
    
    switch (timeRange) {
      case '1Y':
        cutoffDate = new Date(now.setFullYear(now.getFullYear() - 1));
        break;
      case '5Y':
        cutoffDate = new Date(now.setFullYear(now.getFullYear() - 5));
        break;
      default:
        return chartData;
    }
    
    return chartData.filter((d) => {
      const date = new Date(d.Date);
      return date >= cutoffDate;
    });
  }, [chartData, timeRange]);

  const stats = useMemo(() => {
    if (!filteredData.length) return null;
    
    const prices = filteredData.map((d) => d.GLD);
    const currentPrice = prices[prices.length - 1];
    const previousPrice = prices[0];
    const change = ((currentPrice - previousPrice) / previousPrice) * 100;
    const high = Math.max(...prices);
    const low = Math.min(...prices);
    const avg = prices.reduce((a, b) => a + b, 0) / prices.length;
    
    return {
      current: currentPrice,
      change: change.toFixed(2),
      high,
      low,
      avg: avg.toFixed(2),
      isPositive: change >= 0,
    };
  }, [filteredData]);

  const data = {
    labels: filteredData.map((d) => d.Date),
    datasets: [
      {
        label: 'GLD Price ($)',
        data: filteredData.map((d) => d.GLD),
        borderColor: 'hsl(43 74% 49%)',
        backgroundColor: (context: any) => {
          const ctx = context.chart.ctx;
          const gradient = ctx.createLinearGradient(0, 0, 0, 400);
          gradient.addColorStop(0, 'hsla(43, 74%, 49%, 0.3)');
          gradient.addColorStop(1, 'hsla(43, 74%, 49%, 0)');
          return gradient;
        },
        fill: true,
        tension: 0.4,
        pointRadius: 0,
        pointHoverRadius: 6,
        pointHoverBackgroundColor: 'hsl(43 74% 49%)',
        pointHoverBorderColor: '#fff',
        pointHoverBorderWidth: 2,
        borderWidth: 2,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    interaction: {
      intersect: false,
      mode: 'index' as const,
    },
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        backgroundColor: 'hsl(222 40% 10%)',
        titleColor: 'hsl(210 20% 95%)',
        bodyColor: 'hsl(43 74% 49%)',
        borderColor: 'hsl(222 25% 20%)',
        borderWidth: 1,
        padding: 12,
        displayColors: false,
        callbacks: {
          title: (items: any) => `Date: ${items[0].label}`,
          label: (item: any) => `Price: $${item.formattedValue}`,
        },
      },
    },
    scales: {
      x: {
        display: true,
        grid: {
          display: false,
        },
        ticks: {
          color: 'hsl(215 15% 55%)',
          maxTicksLimit: 8,
          font: {
            size: 11,
          },
        },
        border: {
          display: false,
        },
      },
      y: {
        display: true,
        grid: {
          color: 'hsla(222, 25%, 20%, 0.5)',
        },
        ticks: {
          color: 'hsl(215 15% 55%)',
          callback: (value: any) => `$${value}`,
          font: {
            size: 11,
          },
        },
        border: {
          display: false,
        },
      },
    },
  };

  return (
    <section id="chart" className="py-20 gradient-bg">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold font-display mb-4">
            Historical <span className="gold-text">Price Trends</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Explore historical gold price data to understand market patterns and trends
          </p>
        </motion.div>

        {/* Stats Cards */}
        {stats && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8 max-w-4xl mx-auto"
          >
            <div className="glass-card p-4 text-center">
              <div className="flex items-center justify-center gap-2 mb-2">
                {stats.isPositive ? (
                  <TrendingUp className="w-5 h-5 text-success" />
                ) : (
                  <TrendingDown className="w-5 h-5 text-destructive" />
                )}
                <span className="text-sm text-muted-foreground">Change</span>
              </div>
              <div className={`text-2xl font-bold ${stats.isPositive ? 'text-success' : 'text-destructive'}`}>
                {stats.isPositive ? '+' : ''}{stats.change}%
              </div>
            </div>
            <div className="glass-card p-4 text-center">
              <div className="flex items-center justify-center gap-2 mb-2">
                <Activity className="w-5 h-5 text-primary" />
                <span className="text-sm text-muted-foreground">High</span>
              </div>
              <div className="text-2xl font-bold gold-text">${stats.high.toFixed(2)}</div>
            </div>
            <div className="glass-card p-4 text-center">
              <div className="flex items-center justify-center gap-2 mb-2">
                <Activity className="w-5 h-5 text-muted-foreground" />
                <span className="text-sm text-muted-foreground">Low</span>
              </div>
              <div className="text-2xl font-bold">${stats.low.toFixed(2)}</div>
            </div>
            <div className="glass-card p-4 text-center">
              <div className="flex items-center justify-center gap-2 mb-2">
                <Calendar className="w-5 h-5 text-primary" />
                <span className="text-sm text-muted-foreground">Avg</span>
              </div>
              <div className="text-2xl font-bold">${stats.avg}</div>
            </div>
          </motion.div>
        )}

        {/* Time Range Selector */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="flex justify-center gap-2 mb-8"
        >
          {(['1Y', '5Y', 'ALL'] as const).map((range) => (
            <button
              key={range}
              onClick={() => setTimeRange(range)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                timeRange === range
                  ? 'bg-primary text-primary-foreground gold-glow'
                  : 'glass-card hover:bg-accent'
              }`}
            >
              {range === 'ALL' ? 'All Time' : range}
            </button>
          ))}
        </motion.div>

        {/* Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="glass-card p-4 md:p-6 chart-container"
        >
          {isLoading ? (
            <div className="h-[400px] flex items-center justify-center">
              <div className="text-center">
                <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4" />
                <p className="text-muted-foreground">Loading chart data...</p>
              </div>
            </div>
          ) : (
            <div className="h-[400px]">
              <Line data={data} options={options} />
            </div>
          )}
        </motion.div>

        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="text-xs text-muted-foreground text-center mt-4"
        >
          Data source: Historical GLD (SPDR Gold Shares) ETF prices from 2008-2018
        </motion.p>
      </div>
    </section>
  );
};

export default PriceChart;
