import Navigation from '@/components/Navigation';
import HeroSection from '@/components/HeroSection';
import PredictionForm from '@/components/PredictionForm';
import PriceChart from '@/components/PriceChart';
import AboutSection from '@/components/AboutSection';
import Footer from '@/components/Footer';

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <HeroSection />
      <PredictionForm />
      <PriceChart />
      <AboutSection />
      <Footer />
    </div>
  );
};

export default Index;
