export interface GoldPriceData {
  Date: string;
  SPX: number;
  GLD: number;
  USO: number;
  SLV: number;
  'EUR/USD': number;
}

export interface PredictionInput {
  date: string;
  currency: 'INR' | 'USD';
  inflationRate?: number;
  usdIndex?: number;
  interestRate?: number;
}

export interface PredictionResult {
  predictedPrice: number;
  currency: 'INR' | 'USD';
  confidence: number;
  date: string;
  trend: 'up' | 'down' | 'stable';
}

export interface ChartDataPoint {
  date: string;
  price: number;
  predicted?: boolean;
}
